//
// Created by pedro on 01-05-2019.
//

#ifndef PROJECTO_LI_UTILS_H
#define PROJECTO_LI_UTILS_H

#include "estado.h"

void acertaScanf ();
void pressionaA (const char * texto);
void eliminaEspacos (char* info);
VALOR char2Valor (char c);
char valor2char(VALOR v);
void contaPecas (ESTADO * e);

#endif //PROJECTO_LI_UTILS_H
