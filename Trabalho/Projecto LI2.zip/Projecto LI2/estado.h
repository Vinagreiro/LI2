//
// Created by pja on 27/02/2019.
//



#ifndef PROJ_ESTADO_H
#define PROJ_ESTADO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Define as diferentes peças do tabuleiro.
 */
typedef enum {VAZIA, VALOR_X, VALOR_O} VALOR;

/**
 * <br><b> Data fields: </b><br>
 *
 * <b> int x </b> - Número de peças do jogador "X". <br><br>
 * <b> int y </b> - Número de peças do jogador "O". <br><br>
 */
typedef struct posicao {
    int x;
    int y;
} pos;

/**
 * <br><b> Data fields: </b><br>
 *
 * <b> VALOR peca </b> - Peça do jogador atual. <br><br>
 * <b> VALOR grelha [8][8] </b> - Matriz do tabuleiro de jogo. <br><br>
 * <b> char modo </b> - Modo de jogo (automático ou manual). <br><br>
 * <b> VALOR pecaCPU </b> - VALOR da peça do CPU (VAZIA se jogo manual). <br><br>
 * <b> int difCPU </b> - Dificuldade do bot (0 em jogo manual). <br><br>
 * <b> pos pecas </b> - Contagem de peças dos jogadores. <br><br>
 */
typedef struct estado {
    VALOR peca;
    VALOR grelha[8][8];
    char modo;
    VALOR pecaCPU;
    int difCPU;
    pos pecas;
} ESTADO;

/**
 * <br><b> Data fields: </b><br>
 *
 * <b> pos jogadasValidas </b> - Array com todas as jogadas válidas do turno. <br><br>
 * <b> int N </b> - Número de jogadas válidas do turno. <br><br>
 * <b> pos jogadasValidas </b> - Array com todos os eventos do turno. <br><br>
 * <b> int cTurno </b> - Número de eventos do turno.
 */
typedef struct eventos {
    pos jogadasValidas[100];
    int N;
} * Eventos;

void printa(ESTADO * e, pos * sugestao, Eventos * turno, int opcao);
void menu(ESTADO * e);
void escreveEstado (FILE **f, ESTADO e, char* info);
void checkaJogadas(ESTADO * e, Eventos * turno);
void novoTurno (Eventos * turno);
void trocaPeca (VALOR * peca);
void checkaHorizontais (ESTADO * e, Eventos * turno, int y, int x, int * eValida);
void checkaVerticais (ESTADO * e, Eventos * turno, int y, int x, int * eValida);
void efetuaTurno (Eventos * turno, ESTADO * e, int l, int c, int * jogadaAnterior);
void campeonato (char * info);
void alteraVerticais (int y, int x, ESTADO * e);
void alteraHorizontais (int y, int x, ESTADO * e);
void alteraDiagonais (int y, int x, ESTADO * e);
void altera (int y, int x, int varI, int varJ, ESTADO * e);
void jogada (char * info, ESTADO * e, Eventos * turno, pos * previsao, int * jogadaAnterior);
int verificaValida(int y, int x, Eventos * turno);
int finalJogo (pos * pecas, int * N, int * jogadaAnterior);
int jaApareceu (Eventos * turno, int y, int x);
#endif //PROJ_ESTADO_H