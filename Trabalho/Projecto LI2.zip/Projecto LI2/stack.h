//
// Created by pedro on 14-04-2019.
//

#ifndef PROJECTO_LI_STACK_H
#define PROJECTO_LI_STACK_H

#include "estado.h"

/**
 * <br><b> Data fields: </b><br>
 *
 * <b> ESTADO tabuleiro </b> - Matriz com o tabuleiro do jogo <br><br>
 * <b> int N </b> - Endereço da stack com a jogada anterior <br><br>
 */
typedef struct stack {
    ESTADO tabuleiro;
    struct stack * prox;
} * Stack;

Stack inicializaStack (ESTADO e, Stack s);
void reiniciaStack (Stack * s);
void push(Stack * s, ESTADO e);
void pop(Stack *s, ESTADO * e);
#endif //PROJECTO_LI_STACK_H

