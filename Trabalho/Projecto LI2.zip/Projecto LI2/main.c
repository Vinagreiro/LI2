#include <stdio.h>
#include "estado.h"


int main() {
    ESTADO e = {0};

    menu(&e);

    return 0;
}