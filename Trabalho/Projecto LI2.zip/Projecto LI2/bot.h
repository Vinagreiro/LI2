//
// Created by pedro on 01-05-2019.
//

#ifndef PROJECTO_LI_BOT_H
#define PROJECTO_LI_BOT_H
#include "estado.h"
#include <unistd.h>

pos ajudaJogada (ESTADO e, int profundidade);
int simulaJogada (ESTADO e, pos jog, int profundidade, VALOR jogadorInvocador, int matrizValores[8][8]);
void turnoBot (ESTADO * e, pos * previsao, Eventos * turno, int * jogadaAnterior);
void novoJogoBot (char* info, ESTADO *e);
void jogadaBot (ESTADO *e, pos * jogadaDoBot, Eventos * turno);
int estabilidade(ESTADO e, VALOR jogadorInvocador);
int calculaEstabilidade (int y, int x, int varI, int varJ, VALOR jogadorInvocador, ESTADO e);
ESTADO jogadaLight(ESTADO e, pos jogadaAFazer);
int verificaPerimetro (ESTADO e, int i, int j);
int mobilidade (ESTADO e, VALOR jogadorInvocador);
int max (int limite, int N[limite]);
int min (int limite, int N[limite]);
int avalia (ESTADO * e, VALOR jogadorInvocador, int matrizValores[8][8]);
int melhorEscolha (int limite, int N[limite]);
#endif //PROJECTO_LI_BOT_H
