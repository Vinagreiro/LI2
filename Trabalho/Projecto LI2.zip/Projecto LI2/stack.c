//
// Created by pedro on 14-04-2019.
//
#include <stdlib.h>
#include "stack.h"

/**
 * <b>Inicializa uma nova stack</b>
 * @param e - Estado atual do jogo
 * @param s - Stack
 * @return - Nova Stack.
 */
Stack inicializaStack (ESTADO e, Stack s) {
    Stack nova = malloc(sizeof(struct stack));
    if (nova == NULL) {
        printf("O programa encerrou pois não conseguiu aceder à memória.\n");
        exit(1);
    }
    nova->tabuleiro = e;
    nova->prox = s;
    return nova;
}

/**
 * <b> Adiciona uma jogada à stack.</b>
 * @param s - Stack.
 * @param e - Estado atual do jogo.
 */
void push (Stack * s, ESTADO e) {
    Stack nova = inicializaStack(e, *s);
    *s = nova;
}

/**
 * <b> Retira a última jogada à stack ( caso haja jogadas ) .</b>
 * @param s - Stack.
 * @param e - Estado atual do jogo.
 */
void pop (Stack * s, ESTADO * e) {
    if ((*s)->prox != NULL)
        *s = (*s)->prox;
    *e = (*s)->tabuleiro;

    if (e->modo == 'A' && e->pecaCPU == e->peca)
        pop(s, e);
}

/**
 *<b>Liberta a memória alocada para a stack anterior, e cria uma nova.</b>
 * @param s - Stack.
 */
void reiniciaStack (Stack * s) {
    Stack liberta;
    while ((*s)->prox != NULL) {
        liberta = *s;
        *s = (*s)->prox;
        free(liberta);
    }
}

