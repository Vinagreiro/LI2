//
// Created by pedro on 01-05-2019.
//

#include "utils.h"
#include <ctype.h>

/**
 * <b>Retira caracteres '\n' da string obtida pelo scanf.</b>
 */
void acertaScanf () {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

/**
 * <b>Repete mensagem, enquanto o jogador não pressiona a tecla 'A'.</b>
 * @param texto -  Mensagem a repetir.
 */
void pressionaA (const char * texto) {
    char c;

    printf("%s", texto);
    scanf(" %c", &c);

    while (c != 'a') {
        printf("%s", texto);
        scanf(" %c", &c);
    }
    acertaScanf();
}

/**
 * <b>Elimina os espaços do comando do jogador.</b>
 * @param info - Comando do jogador.
 */
void eliminaEspacos (char* info) {
    for (int i = 0; info[i]; i++)
        if (isspace(info[i]) != 0)
            for (int j = i; info[j]; j++)
                info[j] = info[j+1];
}

/**
 * <b> Converte um caractere num valor.</b>
 * @param c - Caractere a converter.
 * @return - Valor resultante.
 */
VALOR char2Valor (char c) {
    switch (c) {
        case '-': return VAZIA;
        case 'X': return VALOR_X;
        case 'O': return VALOR_O;
    }
}

/**
 * <b>Converte um valor em caractere.</b>
 * @param v - Valor a converter em formato VALOR.
 * @return - Caractere resultante.
 */
char valor2char(VALOR v) {
    switch (v) {
        case VALOR_O:
            return 'O';
        case VALOR_X:
            return 'X';
        case VAZIA:
            return '-';
    }
}

/**
 * Conta as peças do jogo e atualiza o campo das peças no estado.
 * @param e - Estado do jogo.
 */
void contaPecas (ESTADO * e) {
    e->pecas.x = 0;
    e->pecas.y = 0;

    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (e->grelha[i][j] == VALOR_X) {
                e->pecas.x++;
            } else if (e->grelha[i][j] != VAZIA)
                e->pecas.y++;
        }
    }
}