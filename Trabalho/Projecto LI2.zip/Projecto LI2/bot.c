//
// Created by pedro on 01-05-2019.
//
#include "bot.h"
#include "utils.h"
/**
 * <b>Calcula a melhor jogada (com profundidade dependente do estado do jogo).</b>
 * @param e - Estado do jogo atual.
 * @param profundidade - Profundidade desejada.
 * @return - A melhor jogada.
 */
pos ajudaJogada (ESTADO e, int profundidade) {
    int movimentosPossiveis[100];
    Eventos ajudaJ;
    novoTurno(&ajudaJ);
    checkaJogadas(&e, &ajudaJ);
    pos r;
    int matrizValores[8][8] = {
            {20,-15,10,10,10,10,-15,20},
            {-15,-15,1,2,2,1,-15,-15},
            {10,1,5,4,4,5,1,10},
            {10,2,4,2,2,4,2,10},
            {10,2,4,2,2,4,2,10},
            {10,1,5,4,4,5,1,10},
            {-15,-15,1,2,2,1,-15,-15},
            {20,-15,10,10,10,10,-15,20}
    };

    for (int i = 0; i < ajudaJ->N; i++)
        movimentosPossiveis[i] = simulaJogada(e, ajudaJ->jogadasValidas[i], profundidade-1, e.peca, matrizValores);
    r = ajudaJ->jogadasValidas[melhorEscolha(ajudaJ->N, movimentosPossiveis)];
    free(ajudaJ);
    return r;
}

/**
 * Percorre a árvore de todas as jogadas possiveis, calculando a valoração das folhas.
 * @param e - Estado do jogo.
 * @param jog - Posição na qual a jogada é feita.
 * @param profundidade - profundidade desejada.
 * @param jogadorInvocador - jogador para a qual a melhor jogada é calculada.
 * @param matrizValores - matriz com os pesos de cada posição do jogo.
 * @return int - Valoração da jogada.
 */
int simulaJogada (ESTADO e, pos jog, int profundidade, VALOR jogadorInvocador, int matrizValores[8][8]) {
    int r = 0;
    if (jog.x != -1) e = jogadaLight(e, jog);

    trocaPeca(&e.peca);
    Eventos turno;
    novoTurno(&turno);
    checkaJogadas(&e, &turno);
    contaPecas(&e);
    int movimentosPossiveis[100];
    int valoracao = avalia(&e, jogadorInvocador, matrizValores);
    int totalPecas = e.pecas.x + e.pecas.y;
    int difPecas = e.pecas.x - e.pecas.y;

    if (totalPecas == 64 || (e.pecas.x == 0 || e.pecas.y == 0))
        r = 3000 * difPecas;
    else if (profundidade == 0) {
        if (totalPecas <= 16)
            if (e.modo == 'A' && e.difCPU == 2 && jogadorInvocador == e.pecaCPU)
                r = turno->N + difPecas;
            else
                r = turno->N + valoracao + estabilidade(e, jogadorInvocador) + mobilidade(e, jogadorInvocador); // 1 3 1
        else if (totalPecas <= 32) {
            if (e.modo == 'A' && e.difCPU == 2 && jogadorInvocador == e.pecaCPU)
                r = turno->N + valoracao + difPecas;
            else
                r = turno->N + valoracao + estabilidade(e, jogadorInvocador); // 1 4 1
        } else if (e.modo == 'A' && e.difCPU == 2 && jogadorInvocador == e.pecaCPU)
            r = turno->N + valoracao * 2 + difPecas * 6;
        else
            r = valoracao + difPecas * 4 + estabilidade(e, jogadorInvocador); // 8 2 1
    } else if (profundidade > 0 && turno->N > 0) {
        for (int i = 0; i < turno->N; i++)
            movimentosPossiveis[i] = simulaJogada(e, turno->jogadasValidas[i], profundidade - 1, jogadorInvocador,matrizValores);

        if (e.peca == jogadorInvocador)
            r = max(turno->N, movimentosPossiveis);
        else r = min(turno->N, movimentosPossiveis);
    } else if (turno->N == 0) {
        if (jog.x == -1) {
            r = 3000 * difPecas;
        } else {
            pos jogadaNula = {-1};
            r = simulaJogada(e, jogadaNula, profundidade - 1, jogadorInvocador, matrizValores);
        }
    }
    free (turno);
    return r;
}

/**
 * Conta o número de peças do jogo e devolve a valoração do tabuleiro relativamente a posições.
 * @param e - Estado do jogo.
 * @param jogadorInvocador - Jogador para o qual o resultado é calculado.
 * @param matrizValores - Matriz com os pesos das posições do tabuleiro.
 * @return Valoração posicional do tabuleiro.
 */
int avalia (ESTADO * e, VALOR jogadorInvocador, int matrizValores[8][8]) {
    int i,j;
    int valoracao = 0;
    e->pecas.x = 0;
    e->pecas.y = 0;
    for (i = 0; i < 8; i++)
        for (j = 0; j < 8; j++)
            if (e->grelha[i][j] == jogadorInvocador) {
                valoracao += matrizValores[i][j];
                e->pecas.x++;
            } else if (e->grelha[i][j] != VAZIA) {
                e->pecas.y++;
                valoracao -= matrizValores[i][j];
            }
    return valoracao;
}

/**
 * Calcula a valoração relativa à heurística da estabilidade.
 * @param y - linha da posição a avaliar.
 * @param x - coluna da posição a avaliar.
 * @param varI - variação na linha a cada iteração do ciclo.
 * @param varJ - variação da coluna a cada iteração do ciclo.
 * @param jogadorInvocador - jogador para o qual a valoração é feita.
 * @param e - Estado atual do jogo.
 * @return - inteiro correspondente à valoração da estabilidade.
 */
int calculaEstabilidade (int y, int x, int varI, int varJ, VALOR jogadorInvocador, ESTADO e) {
    int res = 0, i = y + varI, j = x + varJ, constante;
    VALOR pecaCanto = e.grelha[y][x];

    if (pecaCanto == jogadorInvocador)
        constante = 5;
    else constante = -5;

    while (i <= 7 && i >= 0 && j <= 7 && j >= 0 && e.grelha[i][j] == pecaCanto) {
        res += constante;
        i+=varI;
        j+=varJ;
    }
    return res;
}

/**
 * Utiliza a função calculaEstabilidade a partir de cada um dos cantos para obter o
 * cálculo da estabilidade de todos os cantos.
 * @param e - Estado do jogo.
 * @param jogadorInvocador - Jogador para o qual a valoração é feita.
 * @return - Valor total de estabilidade de todos os cantos.
 */
int estabilidade (ESTADO e, VALOR jogadorInvocador) {
    int res = 0;

    if (e.grelha[0][0] != VAZIA) {
        res += calculaEstabilidade(0, 0, 0, 1, jogadorInvocador, e);
        res += calculaEstabilidade(0, 0, 1, 0, jogadorInvocador, e);
    }
    if (e.grelha[7][0] != VAZIA) {
        res += calculaEstabilidade(7, 0, -1, 0, jogadorInvocador, e);
        res += calculaEstabilidade(7, 0, 0, 1, jogadorInvocador, e);
    }
    if (e.grelha[0][7] != VAZIA) {
        res += calculaEstabilidade(0, 7, 0, -1, jogadorInvocador, e);
        res += calculaEstabilidade(0, 7, 1, 0, jogadorInvocador, e);
    }
    if (e.grelha[7][7] != VAZIA) {
        res += calculaEstabilidade(7, 7, -1, 0, jogadorInvocador, e);
        res += calculaEstabilidade(7, 7, 0, -1, jogadorInvocador, e);
    }

    return res;
}

/**
 * Altera o estado para refletir uma jogada simulada para o bot/sugestão.
 * @param e - Estado do jogo.
 * @param jogadaAFazer - Jogada a simular.
 * @return - Novo estado, após a aplicação da jogada.
 */
ESTADO jogadaLight(ESTADO e, pos jogadaAFazer) {
    e.grelha[jogadaAFazer.y][jogadaAFazer.x] = e.peca;
    alteraHorizontais(jogadaAFazer.y, jogadaAFazer.x, &e);
    alteraVerticais(jogadaAFazer.y, jogadaAFazer.x, &e);
    alteraDiagonais(jogadaAFazer.y, jogadaAFazer.x, &e);

    return e;
}

/**
 * Calcula o número de espaços no perímetro da peça (heurística de fronteira.
 * @param e - Estado do jogo.
 * @param i - Linha da peça para avaliação de fronteira.
 * @param j - Linha da peça para avaliação de fronteira.
 * @return - Valor da fronteira da peça (-1 por espaço vazio).
 */
int verificaPerimetro (ESTADO e, int i, int j) {
    int res = 0;

    if (i > 0 && j > 0)
        res += -1 * (e.grelha[i-1][j-1] == VAZIA);
    if (i > 0)
        res += -1 * (e.grelha[i-1][j] == VAZIA);
    if (i > 0 && j < 7)
        res += -1 * (e.grelha[i-1][j+1] == VAZIA);
    if (j < 7)
        res += -1 * (e.grelha[i][j+1] == VAZIA);
    if (i < 7 && j < 7)
        res += -1 * (e.grelha[i+1][j+1] == VAZIA);
    if (i < 7)
        res += -1 * (e.grelha[i+1][j] == VAZIA);
    if (i < 7 && j > 0)
        res += -1 * (e.grelha[i+1][j-1] == VAZIA);
    if (j > 0)
        res += -1 * (e.grelha[i][j-1] == VAZIA);

    return res;
}

/**
 * Ciclo para verificação de fronteira em cada peça do jogador.
 * @param e - Estado do jogo.
 * @param jogadorInvocador - Jogador para o qual a fronteira é calculada.
 * @return - resultado do total de fronteira das peças do jogador.
 */
int mobilidade (ESTADO e, VALOR jogadorInvocador) {
    int i, j, res = 0;

    for (i = 0, j = 0; i < 8 && j < 8; i++, j++)
        if (e.grelha[i][j] == jogadorInvocador)
            res+= verificaPerimetro(e,i,j);

    return res;
}

/**
 * Efetua o turno do bot, dependendo da dificuldade escolhida e estado do jogo.
 * @param e - Estado do jogo.
 * @param previsao - Posição para onde o bot vai fazer a jogada.
 * @param turno - Informações relativas ao turno.
 * @param jogadaAnterior - 0 se a jogada anterior for passada, 1 caso contrário.
 */
void turnoBot (ESTADO * e, pos * previsao, Eventos * turno, int * jogadaAnterior) {
    contaPecas(e);
    if (e->difCPU == 1)
        *previsao = (*turno)->jogadasValidas[rand() % (*turno)->N];
    else {
        if (e->pecas.x + e->pecas.y > 50)
            *previsao = ajudaJogada(*e, 8);
        else
            *previsao = ajudaJogada(*e, 6);
    }
    jogadaBot(e, previsao, turno);

    printa(e, previsao, turno,0);
    if (previsao->x != -1) {
        printf("O Bot jogou na posicao %d,%d\n\n", previsao->y + 1, previsao->x + 1);
        *jogadaAnterior = 1;
    } else {
        printf("O Bot não teve jogadas possiveis.\n");
        *jogadaAnterior = 0;
    }
    previsao->x = -1; previsao->y = -1;
}

/**
 * Altera o estado de acordo com a jogada do bot.
 * @param e - Estado do jogo.
 * @param jogadaDoBot - Posição onde o bot jogou.
 * @param turno - Informações relativas ao turno.
 */
void jogadaBot (ESTADO *e, pos * jogadaDoBot, Eventos * turno) {
    if ((*turno)->N) {
        e->grelha[jogadaDoBot->y][jogadaDoBot->x] = e->peca;
        alteraDiagonais(jogadaDoBot->y, jogadaDoBot->x, e);
        alteraHorizontais(jogadaDoBot->y, jogadaDoBot->x, e);
        alteraVerticais(jogadaDoBot->y, jogadaDoBot->x, e);
    } else {
        jogadaDoBot->x = -1;
        jogadaDoBot->y = -1;
    }

    trocaPeca(&e->peca);
}

/**
 * <b>Inicia um novo jogo contra o bot.</b>
 * @param info - Comando inserido pelo jogador.
 * @param e - Estado do jogo.
 */
void novoJogoBot (char* info, ESTADO *e) {
    if (info[0] == 'O')
        e->pecaCPU = VALOR_X;
    else
        e->pecaCPU = VALOR_O;

    e->peca = VALOR_X;
    e->difCPU = info[2]-48;
    e -> modo = 'A';

    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++)
            e -> grelha[i][j] = 0;

    e -> grelha[3][4] = VALOR_X;
    e -> grelha[4][3] = VALOR_X;
    e -> grelha[3][3] = VALOR_O;
    e -> grelha[4][4] = VALOR_O;
}

/**
 * Escolhe a valoração com o maior valor e retorna o seu indice.
 * @param limite - Número total de valorações a percorrer.
 * @param N - Array com as valorações.
 * @return - Indice da maior valoração.
 */
int melhorEscolha (int limite, int N[limite]) {
    int maior = N[0];
    int indice = 0;

    for (int i = 0; i < limite; i++)
        if (N[i] > maior) {
            maior = N[i];
            indice = i;
        }
    return indice;
}

/**
 * Calcula o máximo de um array.
 * @param limite - Número de elementos do array.
 * @param N - Array a avaliar.
 * @return - Maior elemento do array.
 */
int max (int limite, int N[limite]) {
    int maior = N[0];

    for (int i = 0; i < limite; i++)
        if (N[i] > maior)
            maior = N[i];

    return maior;
}


/**
 * Calcula o mínimo de um array.
 * @param limite - Número de elementos do array.
 * @param N - Array a avaliar.
 * @return - Menor elemento do array.
 */
int min (int limite, int N[limite]) {
    int menor = N[0];
    for (int i = 0; i < limite; i++)
        if (N[i] < menor)
            menor = N[i];

    return menor;
}