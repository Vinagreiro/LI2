//
// Created by Pedro on 01/03/2019.
//
#include <stdio.h>
#include "stack.h"
#include "estado.h"
#include "bot.h"
#include "utils.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
/**
 *  <b>Função que verifica se a posição é uma jogada válida.</b>
 * @param i -  corresponde à linha.
 * @param j - corresponde à coluna.
 * @param varI - A variação a aplicar à linha em cada iteração.
 * @param varJ - A variação a aplicar à coluna em cada iteração.
 * @param e - Estado actual.
 * @param turno - Informações relativas ao turno actual.
 * @param eValida - 1 se a jogada é válida, 0 caso contrário.
 */
void checka (int i, int j, int varI, int varJ, ESTADO * e, Eventos * turno, int * eValida) {
    int cruzouInimigo = 0, y = i, x = j;

    i += varI;
    j += varJ;

    while (i >= 0 && i <= 7 && j >= 0 && j <= 7 && !(*eValida) && e->grelha[i][j] != VAZIA) {
        if (e->grelha[i][j] != e->peca) {
            cruzouInimigo = 1;
        } else {
            if (cruzouInimigo == 1 && jaApareceu(turno, y, x) == 0) {
                (*turno)->jogadasValidas[(*turno)->N].x = x;
                (*turno)->jogadasValidas[(*turno)->N++].y = y;
                *eValida = 1;
            }
            return;
        }
        i += varI;
        j += varJ;
    }
}

/**
 * <b>Função auxiliar para avaliar se a jogada é válida na diagonal principal.</b>
 * @param e - Estado atual.
 * @param turno - Informações relativas ao turno.
 * @param y - linha da posição a avaliar.
 * @param x - coluna da posição a avaliar.
 * @param eValida - 1 se a jogada é válida, 0 caso contrário.
 */
void checkaDiagPrincipal (ESTADO * e, Eventos * turno, int y, int x, int * eValida) {
    checka(y, x, -1, -1, e, turno, eValida);
    checka(y, x, 1, 1, e, turno, eValida);
}

/**
 * <b>Função auxiliar para avaliar se a jogada é válida na diagonal secundária.</b>
 * @param e - Estado atual.
 * @param turno - Informações relativas ao turno.
 * @param y - linha da posição a avaliar.
 * @param x - coluna da posição a avaliar.
 * @param eValida - 1 se a jogada é válida, 0 caso contrário.
 */
void checkaDiagSecundaria(ESTADO * e, Eventos * turno, int y, int x, int * eValida) {
    checka(y, x, -1, 1, e, turno, eValida);
    checka(y, x, 1, -1, e, turno, eValida);
}

/**
 * <b>Função auxiliar para avaliar se a jogada é válida nas horizontais.</b>
 * @param e - Estado atual.
 * @param turno - Informações relativas ao turno.
 * @param y - linha da posição a avaliar.
 * @param x - coluna da posição a avaliar.
 * @param eValida - 1 se a jogada é válida, 0 caso contrário.
 */
void checkaHorizontais (ESTADO * e, Eventos * turno, int y, int x, int * eValida) {
    checka(y, x, 0, -1, e, turno, eValida);
    checka(y, x, 0, 1, e, turno, eValida);
}
/**
 * <b>Função auxiliar para avaliar se a jogada é válida nas verticais.</b>
 * @param e - Estado atual.
 * @param turno - Informações relativas ao turno.
 * @param y - linha da posição a avaliar.
 * @param x - coluna da posição a avaliar.
 * @param eValida - 1 se a jogada é válida, 0 caso contrário.
 */
void checkaVerticais (ESTADO * e, Eventos * turno, int y, int x, int * eValida) {
    checka(y, x, -1, 0, e, turno, eValida);
    checka(y, x, 1, 0, e, turno, eValida);
}

/**
 * <b>Funcão que verifica se a jogada já é válida.</b>
 * @param turno - Informações relativas ao turno.
 * @param y - linha da posição a avaliar.
 * @param x - coluna da posição a avaliar.
 * @return 1 se a jogada já era válida, 0 caso contrário.
 */
int jaApareceu (Eventos * turno, int y, int x) {
    int res = 0;
    for (int i = 0; i < (*turno)->N && res == 0; i++)
        if ((*turno)->jogadasValidas[i].y == y && (*turno)->jogadasValidas[i].x == x)
            res = 1;
    return res;
}

/**
 * <b>Cria um array com todas as jogadas válidas para o jogador.</b>
 * @param e - Estado atual do jogo.
 * @param turno - Informações relativas ao turno.
 */
void checkaJogadas(ESTADO * e, Eventos * turno) {
    (*turno)->N = 0;
    int eValida;

    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++) {
            eValida = 0;
            if (e->grelha[i][j] == VAZIA) {
                checkaDiagPrincipal(e, turno, i, j, &eValida);
                checkaDiagSecundaria(e, turno, i, j, &eValida);

                checkaHorizontais(e, turno, i, j, &eValida);
                checkaVerticais(e, turno, i, j, &eValida);
            }
        }
}

/**
 * <b>Lê um ficheiro, cujo nome é inserido pelo jogador.</b>
 * @param info - comando inserido pelo jogador.
 * @param f - Endereço de Ficheiro onde se guarda o jogo.
 * @param e - estado atual do jogo.
 */
void rdFile (char* info, FILE** f, ESTADO * e, pos * previsao) {
    char c, dificuldade, peca;

    eliminaEspacos(info);

    *f = fopen(info, "r");
    if (*f == NULL) {
        previsao->y = previsao->x = -2;
        printf("O ficheiro não existe, por favor insira um nome válido.\n");
    } else {
        fscanf(*f, " %c %c %c", &(e->modo), &peca, &dificuldade);

        if (peca == 'O') e->peca = VALOR_O;
        else e->peca = VALOR_X;

        e->difCPU = dificuldade - 48;
        if (e->difCPU != 0)
            e->pecaCPU = 3 - e->peca;

        for (int i = 0; i < 8; i++)
            for (int j = 0; j < 8 && (fscanf(*f, " %c", &c)) != EOF; j++)
                e->grelha[i][j] = char2Valor(c);
        fclose(*f);
    }
}

/**
 * <b>Inicializa um novo jogo (com os parâmetros inseridos pelo jogador).</b>
 * @param info - comando inserido pelo jogador.
 * @param e - Estado atual do jogo.
 */
void novoJogo (char* info, ESTADO *e) {
    if (info[0] == 'O')
        e -> peca = VALOR_O;
    else e -> peca = VALOR_X;

    e -> modo = 'M';
    e -> difCPU = 0;
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++)
            e -> grelha[i][j] = 0;

    e -> grelha[3][4] = VALOR_X;
    e -> grelha[4][3] = VALOR_X;
    e -> grelha[3][3] = VALOR_O;
    e -> grelha[4][4] = VALOR_O;
}

/**
 * <b>Guarda o tabuleiro no ficheiro.</b>
 * @param f - ficheiro de jogo.
 * @param x - Valor de peça a gravar.
 * @param j - coluna.
 */
void escreveFicheiro (FILE **f, VALOR x, int j) {
    switch (x) {
        case VAZIA: fprintf(*f, "%c", '-'); break;
        case VALOR_X: fprintf(*f, "%c", 'X'); break;
        case VALOR_O: fprintf(*f, "%c", 'O'); break;
    }
    if (j != 7)
        fprintf(*f, "%c", ' ');
}

/**
 ** <b>Guarda o jogo no ficheiro.</b>
 * @param f - ficheiro de jogo.
 * @param e - Estado atual do jogo.
 * @param info - nome do ficheiro para onde guardar.
 */
void escreveEstado (FILE **f, ESTADO e, char* info) {
    eliminaEspacos(info);
    *f = fopen(info, "w");

    fprintf(*f, "%c %c %c\n", e.modo, valor2char(e.peca), e.difCPU+48);

    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++)
                escreveFicheiro (f,e.grelha[i][j], j);
        fprintf(*f, "\n");
    }

    fclose(*f);
    printf("*GAME SAVED*\n");
}

/**
 * <b> Troca a peça</b>
 * @param peca -  Peça a trocar.
 */
void trocaPeca (VALOR * peca) {
    if (*peca == VALOR_X)
        *peca = VALOR_O;
    else *peca = VALOR_X;
}

/**
 * <b> Adiciona a alteração ao vetor do turno e vira a peça nessa posição. </b>
 * @param i - Linha inicial.
 * @param j - Coluna inicial.
 * @param y - Linha de paragem.
 * @param x - Coluna de paragem.
 * @param varI - Alteração a fazer à linha em cada iteração.
 * @param varJ - Alteração a fazer à coluna em cada iteração.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param e - Estado do jogo.
 */
void efetuaJogada(int i, int j, int y, int x, int varI, int varJ, ESTADO * e) {
        for (i-=varI, j-=varJ; !(i == y && j == x); i-=varI, j-=varJ)
            trocaPeca(&(*e).grelha[i][j]);
}

/**
 * <b> Efetua as alteraçoes no tabuleiro em cada jogada. </b>
 * @param y - linha a partir da qual a alteração é feita.
 * @param x - coluna a partir da qual a alteração é feita.
 * @param varI - alteração que a linha sofre em cada iteração.
 * @param varJ - alteração que a coluna sofre em cada iteração.
 * @param e - Estado do jogo.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param tipo - 0 para o altera usual, 1 para uma jogada simulada.
 */
void altera (int y, int x, int varI, int varJ, ESTADO * e) {
    int i = y+varI, j = x+varJ, done = 0, cruzouInimigo = 0;
    while (i >= 0 && i <= 7 && j >= 0 && j<= 7 && (e -> grelha[i][j] != VAZIA) && (done == 0)) {
        if (e -> grelha[i][j] != e -> peca) {
            cruzouInimigo = 1;
        } else {
            if (cruzouInimigo == 1)
                efetuaJogada (i, j,y, x, varI, varJ, e);
            done = 1;
        }
        i+=varI;
        j+=varJ;
    }
}

/**
 * <b> Chama a função altera verticalmente. </b>
 * @param y - linha a partir da qual a alteração é feita.
 * @param x - coluna a partir da qual a alteração é feita.
 * @param e - Estado do jogo.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param tipo - 0 para o altera usual, 1 para uma jogada simulada.
 */
void alteraVerticais (int y, int x, ESTADO * e) {
    altera(y,x,-1,0,e);
    altera(y,x,1,0,e);
}

/**
 * <b> Chama a função altera horizontalmente. </b>
 * @param y - linha a partir da qual a alteração é feita.
 * @param x - coluna a partir da qual a alteração é feita.
 * @param e - Estado do jogo.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param tipo - 0 para o altera usual, 1 para uma jogada simulada.
 */
void alteraHorizontais (int y, int x, ESTADO * e) {
    altera(y, x, 0, -1, e);
    altera(y, x, 0, 1, e);
}

/**
 * <b> Chama a função altera para as diagonais. </b>
 * @param y - linha a partir da qual a alteração é feita.
 * @param x - coluna a partir da qual a alteração é feita.
 * @param e - Estado do jogo.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param tipo - 0 para o altera usual, 1 para uma jogada simulada.
 */
void alteraDiagonais (int y, int x, ESTADO * e) {
    altera(y, x, -1, -1, e);
    altera(y, x, -1, 1, e);
    altera(y, x, 1, -1, e);
    altera(y, x, 1, 1, e);
}

/**
 * Adiciona a jogada efetuada ao turno, bem como as alterações.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param e - Estado do jogo.
 * @param l - linha em que a jogada é feita.
 * @param c - coluna em que a jogada é feita.
 */
void efetuaTurno (Eventos * turno, ESTADO * e, int l, int c, int * jogadaAnterior) {
    if ((*turno)->N) {
        e->grelha[l][c] = e->peca;
        alteraDiagonais(l, c, e);
        alteraHorizontais(l, c, e);
        alteraVerticais(l, c, e);
        (*turno)->N = 0;
        *jogadaAnterior = 1;
    }
}

/**
 * <b> Efectua uma jogada.</b>
 * @param info - input de Comando do Jogador.
 * @param e -  Estado do jogo.
 * @param turno - Contém as informações relativas ao turno atual.
 * @param previsao - Indica se foi feita uma sugestão ou uma jogada.
 */
void jogada (char * info, ESTADO * e, Eventos * turno, pos * previsao, int * jogadaAnterior) {
    int l, c;
    eliminaEspacos(info);
    l = info[0] - 49;
    c = info[1] - 49;

    if (e->pecas.x == 0 && e->pecas.y == 0)
        pressionaA("O jogo ainda não começou. Pressione 'a' para voltar ao menu inicial.\n");
    else {
        if ((*turno)->N == 0)
            pressionaA("Não há jogadas válidas. Pressione 'a' para passar o turno ao adversário.\n");
        else if (verificaValida(l, c, turno) == 0) {
            pressionaA("Jogada invalida, por favor aprenda a jogar.\n Pressione 'a' para voltar ao menu.\n");
            return;
        }
    efetuaTurno (turno, e, l, c, jogadaAnterior);
    previsao->x = -1;
    previsao->y = -1;
    trocaPeca(&(*e).peca);
    }
}

/** <b> Verifica se a jogada é válida. </b>
 * @param y - valor da linha.
 * @param x - valor da coluna.
 * @param turno - Contém as informações relativas ao turno atual.
 * @return 1 se a jogada é válida, 0 caso contrário.
 */
int verificaValida (int y, int x, Eventos * turno) {
    int eValida = 0;
    for (int i = 0; i < (*turno)->N && eValida == 0; i++)
        if (y == (*turno)->jogadasValidas[i].y && x == (*turno)->jogadasValidas[i].x)
            eValida = 1;

    return eValida;
}

/**
 * <b>Avalia se há situação de final de jogo.</b>
 * @param pecas - Contagem de peças do jogo.
 * @param N - Número de jogadas válidas deste turno.
 * @param jogadaAnterior - Jogada anterior ( 1 se efectuada, 0 se adversário passou).
 * @return 1 se o jogo acabou, 0 caso contrário.
 */
int finalJogo (pos * pecas, int * N, int * jogadaAnterior) {
        int oJogoAcabou = 0;

        if (pecas->x + pecas->y == 64) {
            if (pecas->y > pecas->x) printf("O Jogador O ganhou o jogo!!!\n");
            else if (pecas->x > pecas->y) printf("O jogador X ganhou o jogo!!!\n");
            else printf("O jogo empatou!!!\n");
            oJogoAcabou = 1;
        }

        if (pecas->x == 0 && pecas->y == 0)
            return 0;
        else if (pecas->x == 0) {
            printf("O jogador O ganhou o jogo!!!\n");
            oJogoAcabou = 1;
        } else if (pecas->y == 0) {
            printf("O jogador X ganhou o jogo!!!\n");
            oJogoAcabou = 1;
        }

        if (*N == 0 && *jogadaAnterior == 0) {
            printf("Não há mais jogadas possíveis para qualquer dos jogadores.\n");

            if (pecas->y > pecas->x) printf("O Jogador O ganhou o jogo!!!\n");
            else if (pecas->x > pecas->y) printf("O jogador X ganhou o jogo!!!\n");
            else printf("O jogo empatou!!!\n");

            oJogoAcabou = 1;
        } else if (*N == 0) *jogadaAnterior = 0;
        else *jogadaAnterior = 1;

        return oJogoAcabou;
}

/**
 * <b> Inicializa a struct de Eventos do turno.</b>
 * @param turno - Contém as informações relativas ao turno atual.
 */
void novoTurno (Eventos * turno) {
    *turno = calloc(1, sizeof(struct eventos));
    if (*turno == NULL) {
        printf("O programa encerrou pois não conseguiu aceder à memória.\n");
        exit(1);
    }
}

/**
 * <b> Permite ao jogador inserir os comandos do jogo. </b>
 * @param e - Estado inicial de jogo
 */
void menu (ESTADO * e) {
    char info[4000];
    char fichTorneio[500];
    FILE *f;
    int jogadaAnterior = 1;
    pos previsao = {-2};
    Stack s = inicializaStack(*e, s);
    Eventos turno;

    printa(e, &previsao, &turno, 0);
    push(&s, *e);
    do {
        novoTurno(&turno);
        checkaJogadas(e, &turno);
        int tipoPrinta = 0;

        if (previsao.x == -1 && finalJogo(&e->pecas, &(turno->N), &jogadaAnterior) == 1)
            return;

        if (e->modo == 'A' && e->peca == e->pecaCPU) {
            turnoBot(e, &previsao, &turno, &jogadaAnterior);
            push(&s, *e);
        } else {
            fgets(info,sizeof(info),stdin);
            switch (info[0]) {
                case 'N':
                    reiniciaStack(&s);
                    novoJogo(info + 2, e);
                    push(&s, *e);
                    break;
                case 'L':
                    reiniciaStack(&s);
                    rdFile(info + 2, &f, e, &previsao);
                    push(&s, *e);
                    break;
                case 'E':
                    escreveEstado(&f, *e, info + 2);
                    break;
                case 'J' :
                    jogada(info + 2, e, &turno, &previsao, &jogadaAnterior);
                    push(&s, *e);
                    break;
                case 'S':
                    previsao.x = -2;
                    tipoPrinta = 1;
                    break;
                case 'H':
                    previsao = ajudaJogada(*e, 6);
                    tipoPrinta = 2;
                    break;
                case 'U':
                    pop (&s, e);
                    break;
                case 'A':
                    reiniciaStack(&s);
                    novoJogoBot(info + 2, e);
                    push(&s, *e);
                    break;
                case 'C':
                    tipoPrinta = 3;
                    if (fichTorneio[0] == '\0')
                        strcpy(fichTorneio, info+2);
                    campeonato(fichTorneio);
                    break;
            }
            printa(e, &previsao, &turno, tipoPrinta);
        }
            free(turno);
    } while (info[0] != 'Q');
    printf("\n Obrigado por jogar Reversi.\n");
}

/**
 * Escreve o ficheiro final depois de um jogo de torneio.
 * @param f - Ficheiro para onde escrever.
 * @param info - Nome do ficheiro original.
 * @param e - Estado final do jogo.
 */
void escreveFicheiroFinal (FILE ** f, char * info, ESTADO e) {
    if (e.pecas.x > e.pecas.y)
        strcat(info, ".gX");
    else if (e.pecas.y > e.pecas.x)
        strcat(info, ".gO");
    else strcat(info, ".g-");
    escreveEstado(f, e, info);
}

/**
 * Altera o modo de jogo para campeonato.
 * @param info - nome do ficheiro a utilizar para o campeonato.
 */
void campeonato (char * info) {
    FILE *f;
    ESTADO e;
    int jogadaAnterior = 1;
    pos previsao;
    previsao.x = -1;
    previsao.y = -1;
    Eventos turno = NULL;

    do {
        rdFile(info, &f, &e, &previsao);
        if (f == NULL) {
            novoJogoBot("X 3", &e);
            printa(&e, &previsao, &turno, 0);
        } else {
            printa(&e, &previsao, &turno, 0);
            novoTurno(&turno);
            checkaJogadas(&e, &turno);
            if (finalJogo(&e.pecas, &turno->N, &jogadaAnterior) == 1)
                escreveFicheiroFinal(&f, info, e);
            turnoBot(&e, &previsao, &turno, &jogadaAnterior);
        }
        escreveEstado(&f, e, info);
        if (previsao.x != -2) {
            free(turno);
            novoTurno(&turno);
            checkaJogadas(&e, &turno);
            if (finalJogo(&e.pecas, &turno->N, &jogadaAnterior) == 1)
                escreveFicheiroFinal(&f, info, e);
        }
        if (previsao.x != -2 && !turno->N) {
            trocaPeca(&e.peca);
            escreveFicheiroFinal(&f, info, e);
            jogadaAnterior = 0;
        }
    } while (previsao.x != -2 && !turno->N);
    if (turno)
        free(turno);
}

/**
 * <b>A função imprime as linhas relativas ao menu à direita do tabuleiro.</b>
 * @param i - Indica a linha a ser impressa no ecrã.
 */
void printaMenu (int i) {
    switch (i) {
        case 0:
            printf("  | A para novo jogo contra bot. O jogador comeca com peça X.\n");
            break;
        case 1:
            printf("  | L<ficheiro>para ler um jogo de ficheiro.\n");
            break;
        case 2:
            printf("  | E <ficheiro> escrever em ficheiro estado do jogo.\n");
            break;
        case 3:
            printf("  | J<L,C>jogar peça atual na posição (l,c).\n");
            break;
        case 4:
            printf("  | S para imprimir um ponto ‘.’nas posições com jogada válida.\n");
            break;
        case 5:
            printf("  | H para sugestão de jogada. Deve ser colocado um ‘?’no sitio sugerido.\n");
            break;
        case 6:
            printf("  | U para desfazer a última jogada(Undo).\n");
            break;
        case 7:
            printf("  | Q para sair do jogo.\n");
            break;
    }
}

/**
 * <b>Função que imprime no ecrã a pontuação do jogo.<\b>
 * @param x - número de peças do jogador "X".
 * @param o - número de peças do jogador "O".
 */
void score (int x, int o) {
    printf("\n* X-%d |SCORE| O-%d *   \n\n  1 2 3 4 5 6 7 8  "" | N <peça>para novo jogo "
           "em que o primeiro a jogar é o jogador com peça.\n", x, o);
}

/**
 * <b>Imprime o estado de jogo atual e o menu.</b>
 * @param e - Estado atual do jogo.
 * @param sugestao - posição da sugestão de jogada.
 * @param turno - Informações relativas ao turno atual.
 * @param opcao - Tipo de print (0 - normal, 1 - jogadas válidas, 2 - sugestão, 3 - torneio).
 */

void printa(ESTADO * e, pos * sugestao, Eventos * turno, int opcao) {
    char c;
    contaPecas(e);

    if (opcao != 3) {
        score(e->pecas.x, e->pecas.y);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (j == 0)
                    printf("%d ", i + 1);
                if (opcao == 1 && verificaValida(i, j, turno) == 1)
                    c = '.';
                else if (opcao == 2 && (*turno)->N != 0 && i == sugestao->y && j == sugestao->x)
                    c = '?';
                else
                    c = valor2char(e->grelha[i][j]);
                printf("%c ", c);
            }
            printaMenu(i);
        }
        if (e->peca == 0) printf("\n");
        else if (e->peca == VALOR_X) printf("Turn: X\n\n");
        else printf("Turn: O\n\n");

        if (opcao == 2 && (*turno)->N != 0)
            printf("A melhor jogada é %d %d.\n\r", sugestao->y + 1, sugestao->x + 1);
        else if (opcao == 2)
            printf("Não há jogadas possíveis.\n");
    }
}